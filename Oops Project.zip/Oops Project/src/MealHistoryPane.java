import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.util.List;

public class MealHistoryPane {

    public static VBox getMealHistoryPane(String username) {
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        // Label for the page title
        Label titleLabel = new Label("Meal History");

        // Create a ListView to display meal history
        ListView<String> mealHistoryList = new ListView<>();

        // Fetch meal history from database and add to the ListView
        List<Meal> meals = MealDAO.getMealHistory(username);
        if (meals == null || meals.isEmpty()) {
            mealHistoryList.getItems().add("No meals logged yet.");
        } else {
            for (Meal meal : meals) {
                mealHistoryList.getItems().add(meal.getMealName() + " | " + meal.getDate() + " | " + meal.getCalories() + " calories");
            }
        }

        // Total Calories Button and Label
        Button totalCaloriesButton = new Button("Calculate Total Calories");
        Label totalCaloriesLabel = new Label("Total Calories: 0");

        totalCaloriesButton.setOnAction(e -> {
            double totalCalories = meals.stream().mapToDouble(Meal::getCalories).sum();
            totalCaloriesLabel.setText("Total Calories: " + totalCalories);
        });

        // View Graph Button
        Button viewGraphButton = new Button("View Graph");
        viewGraphButton.setOnAction(e -> showCalorieGraph(meals));

        // Add components to the layout
        layout.getChildren().addAll(titleLabel, mealHistoryList, totalCaloriesButton, totalCaloriesLabel, viewGraphButton);

        return layout;  // Return VBox (Node)
    }

    private static void showCalorieGraph(List<Meal> meals) {
        // Define the axes
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Date");

        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Calories");

        // Create the BarChart
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Calorie Intake Over Time");
        barChart.setAnimated(false); // Disable animation for clarity

        // Adjust bar and category gaps for thinner bars
        barChart.setCategoryGap(80); // Increase space between categories significantly
        barChart.setBarGap(1);       // Minimize the gap between bars to make them thin

        // Create a series for data
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Calories");

        // Add data to the series
        for (Meal meal : meals) {
            series.getData().add(new XYChart.Data<>(meal.getDate(), meal.getCalories()));
        }

        // Add the series to the chart
        barChart.getData().add(series);

        // Create a VBox for the chart
        VBox chartLayout = new VBox(10);
        chartLayout.setPadding(new Insets(20));
        chartLayout.getChildren().add(barChart);

        // Create a new Scene for the chart
        Scene chartScene = new Scene(chartLayout, 800, 600);

        // Create a new Stage for the chart
        Stage chartStage = new Stage();
        chartStage.setTitle("Calorie Graph");
        chartStage.setScene(chartScene);
        chartStage.show();
    }

}
