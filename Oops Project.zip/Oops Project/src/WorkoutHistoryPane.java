import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import javafx.application.Platform;

import java.util.List;

public class WorkoutHistoryPane {

    public static VBox getWorkoutHistoryPane(String username) {
        VBox layout = new VBox(10);
        layout.setPadding(new Insets(20));

        // Label for the page title
        Label titleLabel = new Label("Workout History");

        // Create a ListView to display workout history
        ListView<String> workoutHistoryList = new ListView<>();

        // Fetch workout history from the database and add to the ListView
        List<Workout> workouts = WorkoutDAO.getWorkoutHistory(username);
        if (workouts == null || workouts.isEmpty()) {
            workoutHistoryList.getItems().add("No workouts logged yet.");
        } else {
            for (Workout workout : workouts) {
                workoutHistoryList.getItems().add(workout.getWorkoutName() + " | " + workout.getDate() + " | " + workout.getDuration() + " minutes");
            }
        }

        // Total Duration Button and Label
        Button totalDurationButton = new Button("Calculate Total Duration");
        Label totalDurationLabel = new Label("Total Duration: 0 minutes");

        totalDurationButton.setOnAction(e -> {
            double totalDuration = workouts.stream().mapToDouble(Workout::getDuration).sum();
            totalDurationLabel.setText("Total Duration: " + totalDuration + " minutes");
        });

        // View Graph Button
        Button viewGraphButton = new Button("View Graph");
        viewGraphButton.setOnAction(e -> showDurationGraph(workouts));

        // Add components to the layout
        layout.getChildren().addAll(titleLabel, workoutHistoryList, totalDurationButton, totalDurationLabel, viewGraphButton);

        return layout;  // Return VBox (Node)
    }

    private static void showDurationGraph(List<Workout> workouts) {
        // Define the axes
        CategoryAxis xAxis = new CategoryAxis();
        xAxis.setLabel("Date");

        NumberAxis yAxis = new NumberAxis();
        yAxis.setLabel("Duration (minutes)");

        // Create the BarChart
        BarChart<String, Number> barChart = new BarChart<>(xAxis, yAxis);
        barChart.setTitle("Workout Duration Over Time");
        barChart.setAnimated(false); // Disable animation for clarity

        // Adjust bar and category gaps for thinner bars
        barChart.setCategoryGap(80); // Increase space between categories significantly
        barChart.setBarGap(1);       // Minimize the gap between bars to make them thin

        // Create a series for data
        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName("Duration");

        // Add data to the series
        for (Workout workout : workouts) {
            XYChart.Data<String, Number> data = new XYChart.Data<>(workout.getDate(), workout.getDuration());
            series.getData().add(data);
        }

        // Add the series to the chart
        barChart.getData().add(series);

        // Set the color of the bars to light green
        barChart.lookupAll(".chart-bar").forEach(node -> node.setStyle("-fx-bar-fill: lightgreen;"));

        // Hide the legend item symbols (the small square)
        barChart.lookupAll(".chart-legend-item-symbol").forEach(node -> node.setOpacity(0));

        // Create a VBox for the chart
        VBox chartLayout = new VBox(10);
        chartLayout.setPadding(new Insets(20));
        chartLayout.getChildren().add(barChart);

        // Create a new Scene for the chart
        Scene chartScene = new Scene(chartLayout, 800, 600);

        // Create a new Stage for the chart
        Stage chartStage = new Stage();
        chartStage.setTitle("Workout Duration Graph");
        chartStage.setScene(chartScene);
        chartStage.show();
    }
}

